# Term Project: team meeting scheduler

## Overview

My base idea for this Project comes from a problem I've experienced that I would like to solve.
I play football for UBC and one of the issues that we have is finding time to have extra meetings.
Everyone is able to be present for practice and the meetings associated with that, but we struggle
when we need to add additional meetings, because everyone's schedule is different.

So I want to create a program that can take schedules as input (whether manually entered or read
from a file). The program can then be asked several things:
- Find the best time to have an extra meeting of given length during the week.
- Input a day of the week, and the best meeting time for that day will be shown
- Show individual's schedules

Then additional features could be implemented with further development - for example
picking meeting times that allow people to leave part way through, or to filter meetings by
position group, or veterans, etc.

Both *coaches* and *players* could use it - anyone who wants to organize a meeting could use the 
application. Would be so helpful not just to me, because it would allow an easier way to create
more time with the team, but also would save the coaches time when trying to organize things for
the week.

## IMPORTANT NOTE FOR GRADER!!
Because it can be slow and tedious to add many players to the team while testing either version, I have added
small items of test code for you to use. For the console based version, there is a method in *SCHEDULER* line 59 that
is commented out callled "testingOnly()". Uncommenting this will add 6 players with varying positions, statuses, and
schedules you can use for testing
For the graphical version, there is a method in *SCHEDULERGUI* line 67 called "testTeam()". Uncomment this to add 5 
players that all have varying postions, and statuses. Schedules must be tested manually, but you can use this
to test display, save and load.
Additionally - currently the GUI will run when main is run. If you need to access the console version, go into *MAIN*, 
comment out the GUI runner, and uncomment the code that runs the console version.

## User Stories
- I want to be able to add a new player to the existing list of players in the database
- I want to be able see **and** filter the current players in the playerbase
- I want to be able to view individual schedules
- I want to be able to be shown the best meeting time 
- I want to be able to modify players traits to account for their development over time (for example 
year on the team, or position)
- I want to have the option when quitting to save the existing state of the program (all players and their schedules remain)
- I want to have the option to reload the save when opening and running the program again to resume where a user left off

## Graphical User Interface User Stories
- I want to be able to add a new player to the interface
- I want to be able to display all players currently in the database
- I want to be able to remove a player from the team database
- I want to have the option to save the session
- I want to have the option to load previous save files
- I want to be able to find the best meeting time from the inputted schedules

# Instructions for Grader (GUI)
- You can generate the first required action related to the user story "adding multiple Xs to a Y" by:
  - Run the GUI
  - Select "Add player"
  - Fill in name, position, and status (strings)
  - Start time and end time. Both must be integers. Time during the day is broken down into 48 30-minute segments.
  - Valid blocks to be busy are between 15 and 30 (8am - 330pm): full description of system is in the Player class
  - Press construct player
- You can generate the second required action related to the user story "adding multiple Xs to a Y" by:
  - Run the GUI
  - Select "Display players"
  - All players currently on the team and their positions are shown
- Third action is removing players from the team:
  - Run the GUI
  - Select "Remove player"
  - Enter the name of the player you want to remove
  - Click remove
- Fourth action is finding the best meeting time:
  - Run the GUI
  - Select "Plan Meeting"
  - The program will run through the schedules uploaded, and find the best time to meet
  - This time will be the one hour block that the most people can attend
  - If all times of day will have a player with a conflict, it will find the time slot with the least amount of conflicts
- You can locate my visual component by looking at the main menu where an image is displayed
- You can save the state of my application by clicking the save button
- You can reload the state of my application by clicking the load button

## PHASE 4 pt 3: Refactoring
The first thing I would refactor if I was given more time would be certain methods in the GUI classes. Both PlayerMenu
and RemoveMenu use the same format of creating a grid with certain labels for the user to input things into. This 
could be refactored and pulled out into an abstract class or helper method that is simply given the amount of rows, and
the label names, and then it will create the given grid.
The second refactoring change I might make would be to have the project constantly updating it's Intervals every time a
player is added, and then the find meeting method simply prints the current best time (as opposed to how it is 
currently, where find meeting calculates all intervals in a large loop as soon as it's called). This would save time
once a full team of 100+ players is added, as the loops may start to slow down when they have to store that many 
intervals. This refactoring would almost ressemble the Observer pattern, where the List of Intervals observes the team,
and each time a player is added, a notify method is called for the List of Intervals to update their scores. This could
either be a separate class built to handle this, or just a method or two added to the GUI class. 
These changes would help with the speed and efficiency of the program, as well as the readability and program flow.