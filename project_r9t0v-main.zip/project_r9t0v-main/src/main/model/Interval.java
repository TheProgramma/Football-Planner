package model;

public class Interval {
    //Represents an interval of the day with a start time,
    // end time, and busy-ness score (Representing how many players will miss the meeting)

    private int start;
    private int end;
    private int busyScore;


    //MODIFIES: this
    //EFFECTS: instantiates a new interval
    public Interval() {
        start = 0;
        end = 0;
        busyScore = 6969;
    }

    public int getStart() {
        return start;
    }

    public int getEnd() {
        return end;
    }

    public int getBusyScore() {
        return busyScore;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public void setEnd(int end) {
        this.end = end;
    }

    public void setBusyScore(int busyScore) {
        this.busyScore = busyScore;
    }
}
