package model;

//import org.json.JSONArray;
import org.json.JSONObject;
import persistence.Saveable;

import java.util.ArrayList;
import java.util.List;

public class Player implements Saveable {

    //Represents a football player with name, position, schedule, and status
    // position must be valid football position
    // status is one of "rookie", "vet", "player"
    // Schedule is list of boolean 48 slots long representing the time of day in
    // half hour increments. True means player is free, false means they have a conflict
    // Only valid true indices are between slots 15-30 (8am - 330pm)

    private String name;
    private String position;
    private List<Boolean> schedule;
    private String status;

    //constructs a player with given name, position, status, and empty schedule
    public Player(String nm, String pos, String st) {
        this.name = nm;
        this.position = pos;
        this.status = st;
        refreshSchedule();
    }

    @Override
    //EFFECTS: writes current player into Json
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("name", this.name);
        json.put("position", this.position);
        json.put("status", this.status);
        json.put("schedule", this.schedule);
        return json;
    }

    //GETTERS
    public String getName() {
        return this.name;
    }

    public String getPosition() {
        return this.position;
    }

    public String getStatus() {
        return this.status;
    }

    public List<Boolean> getSchedule() {
        return schedule;
    }

    //MODIFIES: this
    //EFFECTS: restarts/refreshes schedule back to blank template (full availability)
    public void refreshSchedule() {
        this.schedule = new ArrayList<>();
        for (int i = 1; i <= 48; i++) {
            if (i < 16) {
                this.schedule.add(false);
            } else if (i >= 17 && i <= 31) {
                this.schedule.add(true);
            } else {
                this.schedule.add(false);
            }
        }
    }

    //MODIFIES: this
    //EFFECTS: sets given index to given boolean
    public void setSchedule(int index, String sche) {
        boolean put;
        if (sche.equals("false")) {
            put = false;
        } else {
            put = true;
        }
        this.schedule.set(index, put);
    }



    //SETTERS
    public void changePosition(String pos) {
        this.position = pos;
    }

    public void updateStatus(String status) {
        this.status = status;
    }


    //REQUIRES: 15 <= from <= 29, 16 <= to <= 30
    //MODIFIES: this
    //EFFECTS: blocks off time by changing free time "true" to "false" in
    //         players schedule. Inclusive of from, exclusive of to (so
    //         for example, from 17 to 19 will set 9am-10am unavailable, but
    //         10:01 am is available)
    public void blockTime(int from, int to) {
        for (int i = 0; i <= 47; i++) {
            if (i >= from && i < to) {
                schedule.set(i, false);
            }
        }
    }

}
