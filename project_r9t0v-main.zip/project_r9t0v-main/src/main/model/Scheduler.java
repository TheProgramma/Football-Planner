package model;

import org.json.JSONArray;
import org.json.JSONObject;
import persistence.JsonReader;
import persistence.JsonWriter;
import persistence.Saveable;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Scheduler implements Saveable {

    //Represents the scheduler and database with all added players

    List<Player> team;
    private Scanner input;
    private static final String JSON_STORE = "./data/schedulesave.json";
    private JsonWriter jsonWriter;
    private JsonReader jsonReader;
    private EventLog log = EventLog.getInstance();


    //EFFECTS: runs the scheduler
    public Scheduler() throws FileNotFoundException {
        jsonWriter = new JsonWriter(JSON_STORE);
        jsonReader = new JsonReader(JSON_STORE);
        runScheduler();
    }


    //EFFECTS: writes the team into the Json save file
    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("Team", teamToJson());
        return json;
    }

    //EFFECTS: puts the players in the team into a json array and writes the array into json file
    private JSONArray teamToJson() {
        JSONArray jsonArray = new JSONArray();
        for (Player p : team) {
            jsonArray.put(p.toJson());
        }
        return jsonArray;
    }

    //MODIFIES: this
    //EFFECTS: processes user input to either exit application
    //         or run the processCommand method
    public void runScheduler() {
        boolean keepRunning = true;
        String command = null;
        initializeSystem();
        //testingOnly(); //TEST SUITE HERE

        while (keepRunning) {
            displayMenu();
            command = input.next();
            command = command.toLowerCase();
            if (command.equals("exit")) {
                keepRunning = false;
            } else {
                processCommand(command);
            }
        }
        System.out.println("Thanks for scheduling!");
        for (Event e : log) {
            System.out.println(e.toString());
        }
    }

    //EFFECTS: displays options available to user
    private void displayMenu() {
        System.out.println("SELECT FROM");
        System.out.println("===========");
        System.out.println("\ta -> add a player to the scheduler");
        System.out.println("\tr -> remove a player from the scheduler");
        System.out.println("\tl -> show all players");
        System.out.println("\tp -> plan a meeting");
        System.out.println("\ts -> save team data");
        System.out.println("\tb -> load team data");
        System.out.println("\texit -> end scheduling");
    }

    //EFFECTS: processes command
    private void processCommand(String command) {
        if (command.equals("a")) {
            addPlayer();
        } else if (command.equals("r")) {
            removePlayer();
        } else if (command.equals("l")) {
            listMenu();
        } else if (command.equals("p")) {
            planMeeting();
        } else if (command.equals("s")) {
            saveSchedule();
        } else if (command.equals("b")) {
            loadSchedule();
        } else {
            System.out.println("Invalid input....");
        }
    }


    // MODIFIES: this, EventLog, Event
    // EFFECTS: loads workroom from file
    private void loadSchedule() {
        try {
            team = jsonReader.read();
            System.out.println("Loaded team from: " + JSON_STORE);
            Event newEvent = new Event("Loaded the previous session!");
            log.logEvent(newEvent);
        } catch (IOException e) {
            System.out.println("Unable to read from file: " + JSON_STORE);
        }
    }

    //MODIFIES: this, schedulesave.json, Event, EventLog
    // EFFECTS: saves the workroom to file
    private void saveSchedule() {
        try {
            jsonWriter.open();
            jsonWriter.write(team);
            jsonWriter.close();
            System.out.println("Saved team to: " + JSON_STORE);
            Event newEvent = new Event("Saved the current session!");
            log.logEvent(newEvent);
        } catch (FileNotFoundException e) {
            System.out.println("Unable to write to file: " + JSON_STORE);
        }
    }


    //MODIFIES: this
    //EFFECTS: intializes the scheduler fields and prepares it to run
    private void initializeSystem() {
        input = new Scanner(System.in);
        team = new ArrayList<>();
    }

    //MODIFIES: this, player, Event, EventLog
    //EFFECTS: adds a new player of given specifications to the team list
    private void addPlayer() {
        Player addNew = createPlayer();
        Event newEvent = new Event("Added a new Player to the team! Welcome!");
        log.logEvent(newEvent);
        team.add(addNew);
    }

    //MODIFIES: this, player
    //EFFECTS: creates a new player, giving the option to user to block time,
    //         and adds the player to the team list
    private Player createPlayer() {
        String nm;
        String pos;
        String st;

        System.out.println("Name of player: ");
        nm = input.next();
        System.out.println("Position: ");
        pos = input.next();
        System.out.println("Status (one of: Rookie, Player, Vet): ");
        st = input.next();
        Player ret = new Player(nm, pos, st);
        System.out.println("Block off time? y/n: ");
        String answer = input.next();

        if (answer.equals("y")) {
            blockTime(ret);
        }
        System.out.println("done!");
        return ret;
    }

    //MODIFIES: player
    //EFFECTS: blocks off time in the created player
    private void blockTime(Player ret) {
        boolean again = true;
        String answer;
        do {
            System.out.println("Busy from: ");
            int from = input.nextInt();
            System.out.println("Busy until: ");
            int to = input.nextInt();
            ret.blockTime(from, to);
            System.out.println("Block more time? y/n");
            answer = input.next();
            if (answer.equals("n")) {
                again = false;
            }
        } while (again == true);

    }

    //MODIFIES: this, Event, EventLog
    //EFFECTS: removes player from the team list
    private void removePlayer() {
        String answer = null;
        boolean acc = false;
        System.out.println("Enter the name of the player you want to remove: ");
        answer = input.next();

        for (int i = 0; i < team.size(); i++) {
            String playerName = team.get(i).getName();
            if (answer.equals(playerName)) {
                team.remove(i);
                acc = true;
                break;
            }
        }
        if (acc == true) {
            System.out.println("Player removed");
            Event newEvent = new Event("Removed a player from the team! Goodbye!");
            log.logEvent(newEvent);
        } else if (acc == false) {
            System.out.println("Player not on team");
        }

    }

    //REQUIRES: team is not null
    //MODIFIES: Event, EventLog
    //EFFECTS: displays all players in the team, gives options to see into players
    //         schedules
    private void showList() {
        for (int i = 0; i < team.size(); i++) {
            System.out.println(i + " " + team.get(i).getName() + " " + team.get(i).getPosition());
        }
        Event newEvent = new Event("Displayed all players in the scheduler");
        log.logEvent(newEvent);
    }

    //EFFECTS: shows the menu for the list option and processes user input
    private void listMenu() {
        String option;
        System.out.println("Select what you'd like: ");
        System.out.println("\t all -> show list of all players");
        System.out.println("\t sort -> sort by position");
        System.out.println("\t s -> show individual schedule");

        option = input.next();

        if (option.equals("all")) {
            showList();
        } else if (option.equals("sort")) {
            sortPlayers();
        } else if (option.equals("s")) {
            showSchedule();
        }
    }

    //EFFECTS: prints a list of all players satisfiying the given search condition
    private void sortPlayers() {
        String option;
        System.out.println("Enter the position or status you want to filter for: ");
        option = input.next();

        for (int i = 0; i < team.size(); i++) {
            Player operator = team.get(i);
            if (operator.getPosition().equals(option) || operator.getStatus().equals(option)) {
                System.out.println(i + " " + team.get(i).getName() + " " + team.get(i).getPosition());
            }
        }
    }

    //EFFECTS: shows an individual players schedule
    private void showSchedule() {
        String answer = null;

        System.out.println("Enter the name of the player's schedule you want: ");
        answer = input.next();

        for (int i = 0; i < team.size(); i++) {
            String playerName = team.get(i).getName();
            if (answer.equals(playerName)) {
                printSchedule(team.get(i));
            }
        }
    }

    //EFFECTS: prints schedule
    public void printSchedule(Player player) {
        int hour = 0;
        int minutes = 0;
        for (int i = 0; i < 48; i++) {
            System.out.println(hour + ":" + minutes  + " " + player.getSchedule().get(i));
            minutes += 30;
            if (minutes == 60) {
                minutes = 0;
                hour += 1;
            }
        }
    }

    //REQUIRES: team != null
    //MODIFIES: this
    //EFFECTS: plans a meeting based on best time or best day (option to user)
    private void planMeeting() {
        Interval interval = new Interval();
        for (int i = 15; i <= 29; i++) { //interval loop - goes through each valid interval (1 hour meeting)
            int score = 0; //0 if available for the hour, 1 if half available, 2 if cant make
            int nextHour = i + 1;
            for (int p = 0; p < team.size(); p++) {
               // int score = 0; //0 if available for the hour, 1 if half available, 2 if cant make
                List<Boolean> operate = team.get(p).getSchedule();
                if (operate.get(i) == false) {
                    score += 1;
                }
                if (operate.get(nextHour) == false) {
                    score += 1;
                }
            }
            if (score < interval.getBusyScore()) {
                interval.setStart(i);
                interval.setEnd(nextHour);
                interval.setBusyScore(score);
            }
        }
        meetingHelper(interval);
    }

    //MODIFIES: this, eventLog, Event
    //EFFECTS: helper function for planning meetings
    private void meetingHelper(Interval interval) {
        int start = interval.getStart();
        int end = interval.getEnd();

        printMeetingTime(start, end);
        Event newEvent = new Event("Found the best time to meet! Hope the meeting is productive");
        log.logEvent(newEvent);
    }

    //REQUIRES: start and end are within valid meeting times of the day
    //          (between 8am and 3:30pm)
    //EFFECTS: prints the best time to meet in correct hours and minutes
    public void printMeetingTime(int start, int end) {
        int saveStartHour = 0;
        int saveStartMin = 0;

        int saveEndHour = 0;
        int saveEndMin = 0;

        int hour = 0;
        int minutes = 0;
        for (int i = 0; i < 48; i++) {
            if (i == start) {
                saveStartMin = minutes;
                saveStartHour = hour;
            } else if (i == end) {
                saveEndMin = minutes;
                saveEndHour = hour;
            }
            minutes += 30;
            if (minutes == 60) {
                minutes = 0;
                hour += 1;
            }
        }
        System.out.println("Best time to meet is " + saveStartHour + ":"
                + saveStartMin + " until " + saveEndHour + ":" + saveEndMin);
    }


    private void testingOnly() {
        Player baker = new Player("Baker", "LB", "Vet");
        Player mitch = new Player("mitch", "LB", "Vet");
        Player max = new Player("max", "DB", "Player");
        Player benji = new Player("benji", "DB", "PLayer");
        Player aaron = new Player("aaron", "DL", "Rookie");
        Player samson = new Player("samson", "DL", "Vet");

        baker.blockTime(15, 31);

        mitch.blockTime(14, 31);
        mitch.blockTime(20, 21);

        // max.blockTime(27, 31);

        benji.blockTime(16, 31);

        aaron.blockTime(17, 31);

        samson.blockTime(18, 31);
        samson.blockTime(25, 27);

        team.add(baker);
        team.add(mitch);
        team.add(aaron);
        team.add(max);
        team.add(benji);
        team.add(samson);
    }






}
