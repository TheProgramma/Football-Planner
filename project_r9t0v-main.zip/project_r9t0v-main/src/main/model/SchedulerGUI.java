package model;

import org.json.JSONArray;
import org.json.JSONObject;
import persistence.JsonReader;
import persistence.JsonWriter;
import persistence.Saveable;
import ui.DisplayMenu;
import ui.MessagePopUp;
import ui.PlayerMenu;
import ui.RemoveMenu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SchedulerGUI extends JFrame implements Saveable {

    //Represents the team and scheduler for the graphical version of the project

    static List<Player> team;
    private static final String JSON_STORE = "./data/schedulesave.json";
    private JsonWriter jsonWriter;
    private JsonReader jsonReader;
    private static EventLog log;

    private JFrame window;

    JButton addButton = new JButton("Add player");
    JButton displayButton = new JButton("Display players");
    JButton saveButton = new JButton("Save data");
    JButton loadButton = new JButton("Load data");
    JButton meetingButton = new JButton("Find meeting time");
    JButton removeButton = new JButton("Remove player");


    //MODIFIES: this, GUI (JFrame window?)
    //EFFECTS: runs the scheduler in GUI interface
    public SchedulerGUI() {

        log = EventLog.getInstance();
        team = new ArrayList<>();
        window = new JFrame("Meeting scheduler");
        window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        window.setLayout(new FlowLayout());
        jsonWriter = new JsonWriter(JSON_STORE);
        jsonReader = new JsonReader(JSON_STORE);

        ImageIcon homeScreenImage = new ImageIcon("data/American-Football-Wallpaper-048.jpg");
        JLabel imageLabel = new JLabel(homeScreenImage);

        window.add(new JLabel("Welcome! Select what you'd like to do: "));
        theAddButton();
        theDisplayButton();
        theMeetingButton();
        theRemoveButton();
        theSaveButton();
        theLoadButton();
        window.add(imageLabel);
       // testTeam();

        window.pack();
        window.setVisible(true);

        windowListener();
    }


    //MODIFIES: this
    //EFFECTS: upon window close, print the events log to the console
    public void windowListener() {
        window.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                for (Event evt : log) {
                    System.out.println(evt.toString());
                }
            }
        });
    }

    //REQUIRES: pos, st, be valid, and start, end be valid hours to be busy for
    //MODIFIES: this
    //EFFECTS: creates the given player and adds to the team
    public static void addPlayer(String nm, String pos, String st, int start, int end) {
        Player createNew = new Player(nm, pos, st);
        createNew.blockTime(start, end);
        team.add(createNew);
    }

    //MODIFIES: this, MessagePopUp, Event, EventLog
    //EFFECTS: loads previously saved data into the session
    public void theLoadButton() {
        window.add(loadButton);
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    team = jsonReader.read();
                    System.out.println("Loaded team from: " + JSON_STORE);
                    new MessagePopUp("Loaded the team", 600, 600);
                    Event newEvent = new Event("Loaded the previous session!");
                    log.logEvent(newEvent);
                } catch (IOException exc) {
                    System.out.println("Unable to read from file: " + JSON_STORE);
                    new MessagePopUp("Unable to load, file not found", 600, 600);
                }
            }
        });
    }

    //MODIFIES: this, schedulesave.json, MessagePopUp, Event, EventLog
    //EFFECTS: saves the  current team and writes it into json file
    public void theSaveButton() {
        window.add(saveButton);
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    jsonWriter.open();
                    jsonWriter.write(team);
                    jsonWriter.close();
                    System.out.println("Saved team to: " + JSON_STORE);
                    new MessagePopUp("Saved the current team", 600, 600);
                    Event newEvent = new Event("Saved the current session!");
                    log.logEvent(newEvent);
                } catch (FileNotFoundException exc) {
                    System.out.println("Unable to write to file: " + JSON_STORE);
                    new MessagePopUp("Unable to save, location file not found", 600, 600);
                }
            }
        });
    }

    //MODIFIES: this
    //EFFECTS: finds the best meeting time among all players added and display it to the user
    public void theMeetingButton() {
        window.add(meetingButton);
        meetingButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                    meetingHelper();
                }
        });
    }

    //MODIFIES: this
    //EFFECTS: helper for meeting planner
    private void meetingHelper() {
        Interval interval = new Interval();
        for (int i = 15; i <= 29; i++) { //interval loop - goes through each valid interval (1 hour meeting)
            int score = 0; //0 if available for the hour, 1 if half available, 2 if cant make
            int nextHour = i + 1;
            for (int p = 0; p < team.size(); p++) {
                // int score = 0; //0 if available for the hour, 1 if half available, 2 if cant make
                List<Boolean> operate = team.get(p).getSchedule();
                if (operate.get(i) == false) {
                    score += 1;
                }
                if (operate.get(nextHour) == false) {
                    score += 1;
                }
            }
            if (score < interval.getBusyScore()) {
                interval.setStart(i);
                interval.setEnd(nextHour);
                interval.setBusyScore(score);
            }
        }
        int start = interval.getStart();
        int end = interval.getEnd();

        logAndPopUp(start, end);
    }

    //MODIFIES: this, Event, EventLog, MessagePopUp
    //EFFECTS: logs the event and gives user a prompt message
    private void logAndPopUp(int start, int end) {
        new MessagePopUp("Best time to meet is: " + start + " until " + end, 1000, 1000);
        Event newEvent = new Event("Found the best time to meet! Hope the meeting is productive");
        log.logEvent(newEvent);
    }


    //MODIFIES: this
    //EFFECTS: creates and runs the remove button
    public void theRemoveButton() {
        window.add(removeButton);
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new RemoveMenu();
            }
        });
    }


    //MODIFIES: this, MessagePopUp, Event, EventLog
    //EFFECTS: removes the given player from the team if on the team, else returns error message to user
    public static void removePlayer(String name) {
        String answer = name;
        boolean acc = false;
        for (int i = 0; i < team.size(); i++) {
            String playerName = team.get(i).getName();
            if (answer.equals(playerName)) {
                team.remove(i);
                acc = true;
                break;
            }
        }
        if (acc == true) {
            new MessagePopUp("Player removed", 500, 500);
            Event newEvent = new Event("Removed a player from the team! Goodbye!");
            log.logEvent(newEvent);
        } else if (acc == false) {
            new MessagePopUp("Player not on team", 500, 500);
        }
    }


    //MODIFIES: this, Event, EventLog
    //EFFECTS: runs the add player button in the interface
    public void theAddButton() {
        window.add(addButton);
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PlayerMenu();
                Event newEvent = new Event("Added a new Player to the team! Welcome!");
                log.logEvent(newEvent);
            }
        });
    }


    //MODIFIES: this, Event, EventLog
    //EFFECTS: runs the display player button in the interface
    public void theDisplayButton() {
        window.add(displayButton);
        displayButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DisplayMenu(team);
                Event newEvent = new Event("Displayed all players in the scheduler");
                log.logEvent(newEvent);
            }
        });
    }



    //EFFECTS: writes the team into the Json save file
    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("Team", teamToJson());
        return json;
    }

    //EFFECTS: puts the players in the team into a json array and writes the array into json file
    private JSONArray teamToJson() {
        JSONArray jsonArray = new JSONArray();
        for (Player p : team) {
            jsonArray.put(p.toJson());
        }
        return jsonArray;
    }

    //TEST SUITE ONLY
    public void testTeam() {
        Player ryan = new Player("Ryan", "LB", "Vet");
        Player mitch = new Player("Mitch", "LB/DE", "Vet");
        Player benji = new Player("Benji", "DB", "Player");
        Player lenny =  new Player("Lenny", "WR", "Rookie");
        Player theo = new Player("Theo", "OL", "Captain");

        team.add(ryan);
        team.add(mitch);
        team.add(benji);
        team.add(lenny);
        team.add(theo);
    }





}
