package persistence;

import model.Player;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class JsonReader {

    //Represents a Json Reader to read from a file and load back into session

    private String source;

    // EFFECTS: constructs reader to read from source file
    public JsonReader(String source) {
        this.source = source;
    }

    // EFFECTS: reads team from file and returns it;
    // throws IOException if an error occurs reading data from file
    public List<Player> read() throws IOException {
        String jsonData = readFile(source);
        JSONArray jsonArray = new JSONArray(jsonData);
        return parseTeam(jsonArray);
    }

    // EFFECTS: reads source file as string and returns it
    private String readFile(String source) throws IOException {
        StringBuilder contentBuilder = new StringBuilder();

        try (Stream<String> stream = Files.lines(Paths.get(source), StandardCharsets.UTF_8)) {
            stream.forEach(s -> contentBuilder.append(s));
        }

        return contentBuilder.toString();
    }

    //EFFECTS: helper to split team into players
    private List<Player> parseTeam(JSONArray jsonArray) {
        List<Player> team = new ArrayList<>();
        addTeam(team, jsonArray);
        return team;
    }


    // EFFECTS: parses players from JSON object and adds them to team
    private void addTeam(List<Player> team, JSONArray jsonArray) {
        for (Object json : jsonArray) {
            JSONObject player = (JSONObject) json;
            addPlayer(team, player);
        }
    }

    //EFFECTS: reads info of a single player from file, creates the correct player, and adds into the team
    private void addPlayer(List<Player> team, JSONObject jsonObject) {
        String name = jsonObject.getString("name");
        String position = jsonObject.getString("position");
        String status = jsonObject.getString("status");
        Player player = new Player(name, position, status);

        JSONArray schedule = jsonObject.getJSONArray("schedule");

        int count = 0;
        for (Object o : schedule) {
            player.setSchedule(count, o.toString());
            count++;
        }


        team.add(player);
    }

}
