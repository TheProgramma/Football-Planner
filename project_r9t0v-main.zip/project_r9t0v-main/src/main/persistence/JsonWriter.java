package persistence;

import model.Player;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;


//Represents a writer that transfers current program state to save file

public class JsonWriter {

    private static final int TAB = 4;
    private PrintWriter writer;
    private String destination;


    //EFFECTS: creates Json writer with given destination file to write IN TO
    public JsonWriter(String destination) {
        this.destination = destination;
    }

    // MODIFIES: this
    // EFFECTS: opens writer; throws FileNotFoundException if destination file cannot
    // be opened for writing
    public void open() throws FileNotFoundException {
        writer = new PrintWriter(destination);
    }

    // MODIFIES: this
    // EFFECTS: writes JSON representation of team to file
    public void write(List<Player> team) {
        JSONObject tab = new JSONObject();
        tab.put("Team", helper(team));

    }

    //EFFECTS: helper to split the team properly into an array of json objects
    public JSONArray helper(List<Player> team) {
        JSONArray jsonArray = new JSONArray();

        JSONObject json = null;

        for (Player p : team) {
            json = p.toJson();
            jsonArray.put(json);
        }

        saveToFile(jsonArray.toString(TAB));
        return jsonArray;
    }

    // MODIFIES: this
    // EFFECTS: closes writer
    public void close() {
        writer.close();
    }

    // MODIFIES: this
    // EFFECTS: writes string to file
    private void saveToFile(String json) {
        writer.print(json);
    }
}


