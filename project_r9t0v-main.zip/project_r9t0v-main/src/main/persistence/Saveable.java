package persistence;

import org.json.JSONObject;


public interface Saveable {

    //Represents an interface for saveable content

    // EFFECTS: returns this as JSON object
    JSONObject toJson();
}
