package ui;

import model.Player;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class DisplayMenu {

    //Runs the menu to display all players currently added to the program

    private JFrame displayMenu;
    List<Player> team;
    int width;
    int height;



    //MODIFIES: this
    //EFFECTS: runs the display player menu
    public  DisplayMenu(List<Player> team) {
        displayMenu = new JFrame("Player menu");
        height = 200;
        width = 200;

        displayMenu.setVisible(true);

        this.team = team;

        displayTeam();
        displayMenu.pack();

        displayMenu.setSize(width, height);
        displayMenu.setVisible(true);
    }

    //MODIFIES: this
    //EFFECTS: displays the team
    private void displayTeam() {
        JPanel grid = new JPanel(new GridBagLayout());
        GridBagConstraints con = new GridBagConstraints();
        con.anchor = GridBagConstraints.WEST;
        int x = 0;
        int y = 0;
        con.gridwidth = 1;
        for (Player p : team) {
            height = height +  50;
            width = width + 50;
            con.gridx = x;
            con.gridy = y;
            JLabel show = new JLabel(p.getName() + ": " + p.getPosition());
            grid.add(show, con);
            y++;
        }
        displayMenu.add(grid);
    }
}
