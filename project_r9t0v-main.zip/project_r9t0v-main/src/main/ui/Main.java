package ui;

import model.Scheduler;
import model.SchedulerGUI;

import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) {
        /*try {
            new Scheduler();
        } catch (FileNotFoundException e) {
            System.out.println("unable to find the file");
        }*/

        new SchedulerGUI();



    }
}
