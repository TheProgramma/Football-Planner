package ui;

import javax.swing.*;



public class MessagePopUp extends JFrame {

    //Represents a message pop up that gets displayed to the user


    //MODIFIES: this, SchedulerGUI (JFrame main window?)
    //EFFECTS: creates a new message to inform the user of the given string
    public MessagePopUp(String message, int width, int height) {
        JFrame box = new JFrame();
        JLabel messageLabel = new JLabel(message);
        messageLabel.setSize(width, height);
        box.add(messageLabel);
        box.pack();
        box.setVisible(true);

    }
}
