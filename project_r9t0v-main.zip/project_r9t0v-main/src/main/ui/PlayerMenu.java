package ui;

import model.SchedulerGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PlayerMenu extends JFrame {

    //Runs the menu to add a player to the team

    private JFrame playerMenu;

    //MODIFIES: this, SchedulerGUI
    //EFFECTS: runs the player menu
    public  PlayerMenu() {
        playerMenu = new JFrame("Player menu");
        playerMenu.setSize(500, 300);

        JPanel playerGrid = createGrid();
        playerMenu.getContentPane().add(playerGrid);
        playerMenu.setVisible(true);
    }

    //MODIFIES: this
    //EFFECTS: creates the entry grid
    //GOT TA APPROVAL TO USE SUPPRESS CHECKSTYLE
    @SuppressWarnings({"checkstyle:MethodLength", "checkstyle:SuppressWarnings"})
    private JPanel createGrid() {
        JPanel playerGrid = new JPanel(new GridBagLayout());
        GridBagConstraints con = new GridBagConstraints();
        con.anchor = GridBagConstraints.WEST;


        con.gridx = 0;
        con.gridy = 0;
        con.gridwidth = 1;

        JLabel nameLabel = new JLabel("Player name:");
        playerGrid.add(nameLabel, con);

        con.gridx = 1;
        JTextField nameField = new JTextField(15);
        playerGrid.add(nameField, con);

        con.gridx = 0;
        con.gridy = 1;
        JLabel positionLabel = new JLabel("Player position: ");
        playerGrid.add(positionLabel, con);

        con.gridx = 1;
        JTextField positionField = new JTextField(15);
        playerGrid.add(positionField, con);

        con.gridx = 0;
        con.gridy = 2;
        JLabel statusLabel = new JLabel("Player status:");
        playerGrid.add(statusLabel, con);

        con.gridx = 1;
        JTextField statusField = new JTextField(15);
        playerGrid.add(statusField, con);

        con.gridx = 0;
        con.gridy = 3;
        JLabel startLabel = new JLabel("Start of busy time:");
        playerGrid.add(startLabel, con);

        con.gridx = 1;
        JTextField meetingField = new JTextField(15);
        playerGrid.add(meetingField, con);

        con.gridx = 0;
        con.gridy = 4;
        JLabel endLabel = new JLabel("End of busy time:");
        playerGrid.add(endLabel, con);

        con.gridx = 1;
        JTextField endField = new JTextField(15);
        playerGrid.add(endField, con);

        JButton saveButton = new JButton("Construct Player");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String name = nameField.getText();
                String position = positionField.getText();
                String status = statusField.getText();
                int start = Integer.parseInt(meetingField.getText());
                int end = Integer.parseInt(endField.getText());

                SchedulerGUI.addPlayer(name, position, status, start, end);

                new MessagePopUp(name + " has been added to the roster!", 500, 200);
                playerMenu.setVisible(false);
            }
        });

        playerGrid.add(saveButton);

        return playerGrid;
    }


}
