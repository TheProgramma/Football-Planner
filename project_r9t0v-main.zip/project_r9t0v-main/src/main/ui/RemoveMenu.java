package ui;

import model.SchedulerGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RemoveMenu {

    //Represents and runs the menu to remove a player from the team

    private JFrame removeMenu;

    //MODIFIES: this
    //EFFECTS: runs the remove menu
    public RemoveMenu() {
        removeMenu = new JFrame();

        JPanel removeGrid = createGrid();
        removeMenu.getContentPane().add(removeGrid);
        removeMenu.pack();
        removeMenu.setVisible(true);
    }

    //MODIFIES: this
    //EFFECTS: creates the remove menu grid
    private JPanel createGrid() {
        JPanel removeGrid = new JPanel(new GridBagLayout());
        GridBagConstraints con = new GridBagConstraints();
        con.anchor = GridBagConstraints.WEST;

        con.gridx = 0;
        con.gridy = 0;
        con.gridwidth = 1;

        JLabel nameLabel = new JLabel("Player name to remove:");
        removeGrid.add(nameLabel, con);

        con.gridx = 1;
        JTextField nameField = new JTextField(15);
        removeGrid.add(nameField, con);

        JButton saveButton = new JButton("Remove Player");
        helper(removeGrid, saveButton, nameField);
        return removeGrid;
    }

    //MODIFIES: this
    //EFFECTS: helper class to assist in construction of grid creation
    private void helper(JPanel removeGrid, JButton saveButton, JTextField nameField) {
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                SchedulerGUI.removePlayer(name);

                new MessagePopUp(name + " has been removed from the roster!", 500, 200);
                removeMenu.setVisible(false);
            }
        });
        removeGrid.add(saveButton);
    }
}
