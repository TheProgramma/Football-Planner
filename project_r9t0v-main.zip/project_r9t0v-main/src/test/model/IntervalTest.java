package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class IntervalTest {

    //fields
    Interval day;

    @BeforeEach
    public void runBefore() {
        day = new Interval();
    }

    @Test
    public void testConstructor() {
        assertEquals(0,day.getStart());
        assertEquals(0, day.getEnd());
        assertEquals(6969, day.getBusyScore());
    }

    @Test
    public void testEverything() {
        day.setStart(18);
        day.setEnd(19);
        day.setBusyScore(15);
        assertEquals(18,day.getStart());
        assertEquals(19, day.getEnd());
        assertEquals(15, day.getBusyScore());

    }
}
