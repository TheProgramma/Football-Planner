package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PlayerTest {

    //fields
    Player max;
    Player mitch;
    Player efosuh;
    List<Boolean> firstList;

    @BeforeEach
    public void setUp() {
        max = new Player("Max", "DB", "Player");
        mitch = new Player("Mitch", "LB", "Vet");
        efosuh = new Player("Efosuh", "DL", "Rookie");
        initialize();
    }

    @Test
    public void testConstructor() {
        assertEquals("Max", max.getName());
        assertEquals("DB", max.getPosition());
        assertEquals("Player", max.getStatus());
        assertEquals(firstList, max.getSchedule());
    }

    @Test
    public void testBlockTime(){
        assertEquals(firstList, mitch.getSchedule());
        mitch.blockTime(17, 19);
        firstList.set(17, false);
        firstList.set(18, false);
        assertEquals(firstList, mitch.getSchedule());
        mitch.blockTime(17, 19);
        assertEquals(firstList, mitch.getSchedule());

        mitch.blockTime(25, 29);
        firstList.set(25, false);
        firstList.set(26, false);
        firstList.set(27, false);
        firstList.set(28, false);
        assertEquals(firstList, mitch.getSchedule());

        mitch.blockTime(20, 21);
        firstList.set(20, false);
        assertEquals(firstList, mitch.getSchedule());
    }

    @Test
    public void testExtras(){
        assertEquals("Rookie", efosuh.getStatus());
        assertEquals("LB", mitch.getPosition());
        assertEquals("Max", max.getName());
    }

    @Test
    public void testUpdateStatus() {
        efosuh.updateStatus("Player");
        assertEquals("Player", efosuh.getStatus());

        max.updateStatus("Vet");
        assertEquals("Vet", max.getStatus());

        mitch.updateStatus("Rookie");
        assertEquals("Rookie", mitch.getStatus());
    }

    @Test
    public void testUpdatePosition() {
        efosuh.changePosition("DB");
        assertEquals("DB", efosuh.getPosition());

        efosuh.changePosition("LB");
        assertEquals("LB", efosuh.getPosition());

        mitch.changePosition("DL");
        assertEquals("DL", mitch.getPosition());
    }

    private void initialize()  {
            this.firstList = new ArrayList<>();
        for (int i = 1; i <= 48; i++) {
            if (i < 16) {
                this.firstList.add(false);
            } else if (i >= 17 && i <= 31) {
                this.firstList.add(true);
            } else {
                this.firstList.add(false);
            }
        }
    }




}