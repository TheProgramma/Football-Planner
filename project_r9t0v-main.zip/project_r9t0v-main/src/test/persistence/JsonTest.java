package persistence;

import model.Player;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class JsonTest {
    protected void checkPlayer(String name, String position, String status, List<Boolean> schedule, Player player) {
        assertEquals(name, player.getName());
        assertEquals(position, player.getPosition());
        assertEquals(status, player.getStatus());
        assertEquals(schedule, player.getSchedule());

    }
}
