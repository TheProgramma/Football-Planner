package persistence;

import model.Player;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class JsonWriterTest extends JsonTest{

    Player mitch;
    Player steve;

    @BeforeEach
    void runBefore() {
        mitch = new Player("mitch", "LB", "Vet");
        steve = new Player("steve", "QB", "Rookie");
    }

    @Test
    void testInvalidFile() {
        try {
            JsonWriter writer = new JsonWriter("./data/my\0illegal:fileName.json");
            writer.open();
            fail("IOException was expected");
        } catch (IOException e) {
            // pass
        }
    }

    @Test
    void testEmptyTeam() {
        try {
            List<Player> team = new ArrayList<>();
            JsonWriter writer = new JsonWriter("./data/empty.json");
            writer.open();
            writer.write(team);
            writer.close();

            JsonReader reader = new JsonReader("./data/empty.json");
            team = reader.read();
            assertEquals(0, team.size());
        } catch (IOException e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    void testWorks() {
        try {
            List<Player> team = new ArrayList<>();
            team.add(mitch);
            team.add(steve);
            JsonWriter writer = new JsonWriter("./data/writersuccess.json");
            writer.open();
            writer.write(team);
            writer.close();

            JsonReader reader = new JsonReader("./data/writersuccess.json");
            List<Player> test = reader.read();
            assertEquals(2, test.size());
            List<Boolean> mitchSched = test.get(0).getSchedule();
            checkPlayer("mitch", "LB", "Vet", mitchSched, test.get(0));

        } catch (IOException e) {
            fail("Exception should not have been thrown");
        }
    }

}
